# status_dlog.md — Dashboard PLAN DLOG (CBMPE)

> Última atualização: sessão de reconstrução para o padrão "pronto para integração" (card embutido, Chart.js, DASHBOARD_DATA).
> Fonte de dado usada para popular o protótipo: export "NOVO CONTROLE - PLAN DLOG.xlsx" de 08/09/2026.
> Fonte de verdade do relatório original: Looker Studio "Controle DLOG" (Igor tem acesso de editor).

## Estrutura técnica

- HTML é conteúdo de card puro — sem sidebar/topbar/breadcrumb (o sistema anfitrião fornece).
- 6 abas com navegação horizontal (scroll em telas estreitas): Planejamento, Planejamento (Detalhamento), Distribuição, Distribuição (Visão Mapa), Controle de Processos, Gestão DPL.
- Chart.js v4.4.0 embutido inline (via npm, sem CDN). **Exceção documentada:** a aba "Distribuição (Visão Mapa)" usa SVG customizado em vez de Chart.js — é um mapa geográfico esquemático de Pernambuco por coordenadas de cidade, e Chart.js não tem tipo de gráfico geográfico nativo. Todo o resto do dashboard usa Chart.js.
- Fonte Inter embutida via `@font-face` base64 (pesos 400/600/700/800), sem `fonts.googleapis.com`.
- Contrato de dados único: objeto `DASHBOARD_DATA` no topo do script, com blocos `distribuicao`/`planejamento`/`processos`/`gestao`, cada um com campo `status` ('confirmed' ou 'hypothesis') e a fórmula original documentada em comentário onde aplicável.
- Ponto único de integração: `reloadDashboardData(tabId, filtros)`, marcado com `// TODO (integração)`. Hoje filtra os arrays estáticos em memória com uma latência simulada (320-580ms); ao integrar, só o corpo desta função muda.
- Spinner de carregamento simulado em toda troca de filtro (overlay + `.dlog-spinner` por aba).
- Estado vazio: mensagem "Nenhum dado encontrado para o filtro atual." quando um gráfico ou tabela filtrados ficam sem linhas.
- Listas de opção centralizadas via `uniqueValsFrom()` — nunca duplicadas entre dropdowns.
- Responsivo abaixo de ~900px: grid de 2 colunas colapsa pra 1, filtros quebram linha, abas viram scroll horizontal.
- Paleta extraída por amostragem de pixel do sistema anfitrião: `#C51132` (accent), `#F0DEE1` (fundo do accent), `#161A22` (texto primário), `#828A99` (texto secundário), `#F4F4F4` (fundo), `#FFFFFF` (cartão). As cores dos gráficos (azul/laranja/roxo etc.) são semânticas de dado, não de marca, e foram mantidas da versão anterior — nunca validadas por amostragem porque o Looker Studio original não teve pixels extraídos para elas.

## "Ano Referência" — parâmetro global

Não é uma coluna da planilha — é um parâmetro do relatório Looker Studio original (confirmado no editor por Igor). Modelado aqui como estado JS global (`anoReferencia`), compartilhado pelas 4 abas que dependem dele (Planejamento, Planejamento Detalhamento, Controle de Processos, Gestão DPL). Mudar em qualquer uma re-renderiza as outras três. O botão "Redefinir" de qualquer uma dessas 4 abas também volta o Ano Referência para o padrão (2026) e ressincroniza as demais.

## O que foi validado (fonte: editor Looker Studio, fórmulas reais extraídas por Igor)

| Item | Fórmula | Status | Evidência |
|---|---|---|---|
| Classificação de situação (Planejamento) | `Status_Unificado` | ✅ confirmado | Fórmula vista no editor; A INICIAR bate a R$249 do print de referência (0,0008%) |
| Total de processos (Controle de Processos) | `Filtro de Transbordo` | ✅ confirmado | Fórmula vista no editor; 110 processos, 37/36/17/12/3/2/2/1 por situação — exato |
| Total de processos (Gestão DPL) | `Filtro de Transbordo` + exclusão Tipo="DOAÇÃO" (`Excluir_Doações`) | ✅ confirmado | 87 processos — exato |
| "Processos com sucesso" (Gestão DPL) | `Filtro_Transbordo_Com_Sucesso` | ✅ confirmado | 34/34 — exato |
| Total Distribuição | soma direta de `BaseDash` | ✅ confirmado | R$ 101.423.223,02 — exato, ranking por destino bate item a item |

## O que NÃO foi confirmado (hipótese testada por tentativa/erro)

**P-1 — Card "CONTRATAÇÃO" (aba Planejamento):** o valor usado para itens no status CONTRATADO é `Valor Real DGC` (valor real negociado pós-contrato) em vez do valor planejado, quando disponível. Essa regra **não tem fórmula confirmada** — foi descoberta testando numericamente contra o print de referência (reduziu a diferença de 5,5% pra 3,5%). Testamos também um campo chamado `Valor_Planejado_1_e_2` (fórmula real, vista no editor) — não fez diferença nesse card porque a condição dele nunca se aplica aos itens contratados no próprio Ano Referência.
**Próximo passo sugerido:** Igor clicar direto no scorecard "CONTRATAÇÃO" (não no gráfico de barras) na aba Planejamento do Looker Studio, aba "Configuração" → ver o campo exato em "Métrica".

## Divergências encontradas, sem solução ainda

- **D-1:** Card "EM ANDAMENTO" (Planejamento) fica ~0,5% acima do print de referência mesmo com a fórmula confirmada — testamos a fórmula `Filtro_Transbordo_Em_Andamento` (também confirmada, mais simples que `Status_Unificado`) e deu a mesma soma exata, então não é erro de fórmula. Atribuído a defasagem normal entre a exportação estática da planilha e o relatório ao vivo (mesmo padrão visto em outros itens — ex: total de Controle de Processos foi 110 num print mais antigo e 115 num mais novo, diferença de +5 no mesmo intervalo de tempo).
- **D-2:** Total da aba Distribuição em tabela (R$ 100.867.902,01, visto num print) diverge do total da aba Mapa (R$ 101.423.223,02, que bate exato com `BaseDash`) em ~R$555 mil — nunca identificamos um filtro que explique a diferença; pode ser só os dois prints terem sido tirados em momentos diferentes da planilha viva. O protótipo usa o valor do Mapa (validado).

## Pendências claras — o que falta e de quem depende

| # | O que falta | De quem depende |
|---|---|---|
| P-1 | Fórmula real do campo/métrica do card "CONTRATAÇÃO" | Igor (Looker Studio, editor) |
| P-2 | Linha "Processos por mês" (Gestão DPL) usa `Data Planejamento` como suposição — nunca confirmamos o campo real | Igor (Looker Studio, editor) |
| P-3 | "Média de dias" (Gestão DPL) — não sabemos se o relatório original filtra por Ano Referência também | Igor (Looker Studio, editor) |
| P-4 | "% de recebimento" (Planejamento Detalhamento) hoje NÃO filtra por Ano Referência (usa recebidos de qualquer ano) — não confirmado se deveria | Igor (Looker Studio, editor) |
| P-5 | Coluna "SETOR" (Controle de Processos) usa `SETOR DE PENDÊNCIA`; o print mostra "SETOR RE..." cortado, pode ser campo diferente ("SETOR RESPONSÁVEL") | Igor (Looker Studio, editor) |
| P-6 | Relação entre `BaseDash`, `db_DISTRIBUICAO` e `#ITEM_DPL` na planilha de origem — usamos só `BaseDash` (validado), nunca entendemos se as outras têm algo a mais | Igor (planilha de origem) |
| P-7 | SQL/definição de cada query, para quando o banco real for integrado | Valério (dono da integração — não Igor, que só tem acesso leitura ao Looker Studio, sem SQL) |
| P-8 | Ver `DASHBOARD_DATA.planejamento.itens` — 30% do valor planejado não tem item correspondente em `#PLAN` (só existe no nível de processo, `#DPL`); esses processos aparecem nos cards mas não na tabela linha-a-linha de "Planejamento (Detalhamento)" | Sem ação clara — registrado para consciência do Valério |

## Decisões tomadas

- **2026-09 (Igor):** todos os dashboards, incluindo DLOG, são embutidos como card no sistema anfitrião — sem sidebar/topbar próprias. Isso reverteu uma decisão anterior de dar ao DLOG uma casca visual completa (sidebar vinho + topbar) inspirada no sistema do organograma; essa versão foi descontinuada nesta sessão.
- **2026-09 (Igor):** confirmado que "Painéis BI - DW" é o nome do projeto guarda-chuva inteiro, não mais um dashboard individual a construir — corrigido no registro do projeto.
