# Status — Dashboard de Vacinações (DAS)

## Decisões registradas

**2026-09-14 — Paleta visual corrigida para vermelho/bordô.** A paleta
navy/branco usada na primeira versão do protótipo era uma aproximação de
memória, nunca validada. Igor enviou um print do sistema anfitrião "Painel
de Controle", do qual foram extraídos tokens reais por amostragem de pixel:
sidebar/borda de destaque `#970706`, accent/badge/ícone `#C51132`, fundo de
badge `#F0DEE1`, fundo de conteúdo `#F4F4F4`, fundo de card `#FFFFFF`, texto
primário `#161A22`, texto secundário `#828A99`. Tipografia: Inter. O
`index.html` foi reconstruído do zero com essa paleta.

**2026-09-14 — Upgrade para o padrão técnico "pronto para integração".**
Igor definiu (no contexto de um projeto paralelo, "Painéis BI - DW", cujo
início como projeto separado foi depois descartado) um padrão técnico que
deve valer para todos os dashboards CBMPE. Aplicado retroativamente a este
projeto: zero dependência externa (Chart.js e fonte Inter embutidos via npm,
sem CDN), contrato `DASHBOARD_DATA` único e comentado com flag
confirmado/não confirmado por campo, funções de render com
`chart.destroy()` antes de recriar, `reloadDashboardData(tabId, filtros)`
como ponto único de integração (`// TODO (integração)`), spinner de
carregamento simulado ao trocar filtro, estado vazio com mensagem, listas
de filtro centralizadas em JS.

Projeto independente dos demais (PLAN DLOG, Dashboard de Ocorrências, Dashboard Pessoal).
Segue o mesmo padrão de trabalho: protótipo estático em `index.html`, validado numericamente
a partir dos prints do Metabase, sem inferência de dado não confirmado. Integração com banco
ao vivo fica a cargo do Valério.

## Estrutura do dashboard original (Metabase)
4 abas: **Visão geral**, Execução e logística, Linha do tempo, Indicador de participação.
Filtros globais na Visão geral: "Escolha uma campanha", "Escolha uma vacina", "Período".

## Aba 01 — Visão geral
Status: **parcialmente prototipada** — 4 de 5 quadrantes construídos e validados.

| Quadrante | Status | Fonte |
|---|---|---|
| Total de vacinas aplicadas (3.030) | ✅ validado | print, bate com soma de "Vacinas aplicadas por campanha" |
| Total de campanhas efetuadas (10) | ✅ validado | print, bate com contagem de categorias do gráfico de campanhas |
| Vacinas aplicadas por campanha (10 categorias) | ✅ validado | print |
| Total de aplicações por OME (10 linhas) | ✅ validado | print detalhado (tabela "Total de aplicações por OME", somente leitura) — resolveu ambiguidade de linha duplicada visual ("2º GRUPAMENTO DE BOMBEIROS" aparece 1x, não 2x) |
| Vacinas mais aplicadas (8 linhas) | ✅ validado | print detalhado (tabela "Vacinas mais aplicadas", editado por Valério Ferreira de Albuquerque Filho) — resolveu ambiguidade de linha duplicada visual ("INFLUENZA GRIPE - 2026" aparece 1x, não 2x) |
| **Vacinações mensais** (linha temporal jan/2018–2026) | 🔴 **bloqueado** | print mostra só a forma da curva (picos visuais próximos a jan/2023, jan/2025, jan/2026), sem valores exatos por mês. **Necessário SQL ou export com contagem por mês para construir o gráfico.** |

**Observação sobre os totais parciais:** as listas de OME (soma 1.884) e de vacinas (soma 2.254)
não somam o total geral (3.030) — são top-N exibidos no card original do Metabase, não a base
completa. Não tratado como inconsistência.

**Filtros:** replicados visualmente ("Escolha uma campanha", "Escolha uma vacina", "Período"),
com opções populadas a partir das categorias já validadas. **Sem função de filtragem ainda** —
os dados disponíveis são agregados (top-N por card), não registros brutos; filtrar de fato
exige dado bruto por vacinação individual, ainda não recebido.

**SQL de origem:** ainda não recebido para nenhum quadrante desta aba (Igor sinalizou que vai
enviar). Sem SQL confirmado, os campos/tabelas de origem no banco de produção são desconhecidos
— Valério vai precisar mapear a partir do zero, ou aguardar o SQL prometido por Igor.

## Aba 02 — Execução e logística
Status: **construída e validada** (com uma ressalva sinalizada abaixo).

| Quadrante | Status | Fonte |
|---|---|---|
| Postos de vacinação com maior número de aplicações (7 categorias) | ✅ validado | print — soma parcial (2.333) abaixo do total geral (3.030), consistente com lista top-N |
| Maiores aplicadores (7 pessoas) | ✅ validado | print — soma parcial (2.662), mesma lógica de top-N |
| Representatividade das marcas (donut, 5 marcas) | ✅ **validado — ambiguidade resolvida em 2026-09-15** | print detalhado trouxe contagens absolutas (Instituto Butantan 1.019, Serum Institute of India 294, Fiocruz 174, Pfizer Manufacturing Belgium NV 112, Biofarma 100 — soma 1.699) que reconciliam exatamente com os % do gráfico original, confirmando o mapeamento fatia↔marca. A "BIOFARMA" duplicada na legenda era mesmo um glitch visual — só 5 marcas reais. |

## Aba 03 — Linha do tempo
Status: **não construída, bloqueada por complexidade de leitura segura.**
O print mostra "Vacinações mensais" com ~20 séries (uma por vacina) sobrepostas ao longo de
96 meses (jul/2018–abr/2026), com rótulos numéricos densos. Ler os valores da imagem com
segurança suficiente para atribuir cada número à vacina E ao mês corretos não é viável —
risco real de atribuição errada. Igor confirmou que esta aba também está em modo "somente
leitura" (sem SQL). Pedido pendente: CSV/export da tabela (mês × vacina × contagem), ou
verificar se existe botão de exportação disponível mesmo em modo somente leitura.

## Aba 04 — Indicador de participação
Status: **casca construída com exemplo estático — não funcional.**
Esta aba é interativa por natureza no Metabase (2 filtros: vacina e OME, ambos recalculam
4 valores a partir de dado individual militar × vacina × OME). Replicamos a interface e os
4 valores exatamente como capturados no print (vacina = "Covid-19 D1", OME = "65 seleções"):
Vacina selecionada, Militares que tomaram (35), Efetivo total (4.178), Percentual (0,84% —
consistente com 35/4.178). Os filtros ficam visíveis mas não recalculam nada, porque não
temos o dado bruto necessário (roster militar × vacinação individual × OME). Isso está
avisado na própria tela do dashboard, não só aqui.

## Pendências gerais (atualizado 2026-09-15)
1. SQL/export do gráfico "Vacinações mensais" (Visão geral, total agregado por mês) — Igor
   confirmou acesso somente leitura, sem SQL.
2. SQL/export de "Vacinações mensais por vacina" (Linha do tempo, 20 séries) — Igor confirmou
   acesso somente leitura, sem SQL.
3. SQL de todos os quadrantes já validados por print, prometido por Igor — ainda não recebido
   em nenhuma aba. **Igor está em modo "somente leitura" em todo o dashboard — quando o
   Valério for integrar o banco, o SQL/consulta de cada quadrante precisa ser levantado por
   ele, não pedido a Igor.**
4. **AVISO PARA O VALÉRIO — "Indicador de participação" precisa de base granular.** Essa aba
   não dá pra integrar como os outros quadrantes (que são agregados tipo "contagem por
   categoria"). Ela precisa de dado no nível de registro individual: militar × vacina × OME
   (quem tomou o quê, em qual unidade), para poder recalcular "militares que tomaram",
   "efetivo total" e o percentual toda vez que o filtro de vacina/OME mudar. Hoje a tela só
   mostra o exemplo congelado do print (Covid-19 D1 → 35/4.178/0,84%). Isso está avisado
   também na própria tela do dashboard.
5. Confirmar se o nome exato da fonte (Inter) usada no host "Painel de Controle" está correto
   — foi inferido visualmente por semelhança, não confirmado via inspeção de CSS do sistema
   anfitrião. (Igor confirmou que não é bloqueante — "sem problemas".)
6. Confirmar encaixe real do HTML no "Painel de Controle" (iframe vs. injeção direta no DOM)
   quando o Valério for integrar. (Igor confirmou que não é bloqueante agora — "sem
   problemas".)
